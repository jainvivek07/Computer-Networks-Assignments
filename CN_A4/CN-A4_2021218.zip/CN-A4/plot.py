import matplotlib.pyplot as plt
from scapy.all import *

pcap_file = 'packets.pcap'
seq_numbers = []
timestamps = []
packets = rdpcap(pcap_file)

for packet in packets:
    if 'TCP' in packet and 'IP' in packet:
        seq_numbers.append(packet[TCP].seq)
        timestamps.append(packet.time)

congestion_window = [float('nan')]
for i in range(1, len(seq_numbers)):
    time_diff = timestamps[i] - timestamps[i-1]
    seq_diff = seq_numbers[i] - seq_numbers[i-1]
    cwnd = seq_diff / time_diff if time_diff > 0 else float('nan')
    congestion_window.append(cwnd)

timestamps = timestamps[15:-10]
congestion_window = congestion_window[15:-10]
plt.plot(timestamps, congestion_window)
plt.xlabel('Time (seconds)')
plt.ylabel('Congestion Window Size')
plt.title('Congestion Window Evolution Over Time')
plt.show()