#include "tcp_receiver.hh"

#include <algorithm>
#include <string>
#include <vector>

using namespace std;

bool TCPReceiver::segment_received(const TCPSegment &seg) {
    const TCPHeader head = seg.header();
    auto data = seg.payload();
    // ...
    bool closeInput = false;
    if ((head.syn == true && _synReceived == true) || (head.fin == true && _finReceived == true)) {
        return false;
    }

    uint64_t rec = 1;
    if (head.syn == true && _synReceived == false) {
        _isn = head.seqno;
        nextSeqno= unwrap(_isn+1,_isn,_isn.raw_value());
        raw = nextSeqno;
        _synReceived=true;
    }

    if (head.fin == true && _finReceived == false) {
        _finReceived=true;
        closeInput = true;
    }
    bool haveNext = true;
    if (data.size()==0 && closeInput == true && haveNext == true) {
            stream_out().end_input();
            nextSeqno++;
        // return true;
    }else if(data.size()==0 && closeInput == false){
        return true;
    }

    if (_synReceived == true) {
        bool proceed = false;
        
        uint64_t lskip = max(unwrap(head.seqno,_isn,nextSeqno),nextSeqno) - unwrap(head.seqno,_isn,nextSeqno);
        uint64_t rskip = unwrap(head.seqno,_isn,nextSeqno)+data.size()-1 - min(unwrap(head.seqno,_isn,nextSeqno)+data.size()-1 ,nextSeqno+window_size()-1);
        if (lskip+rskip>=data.size() && proceed == false) {
            return false;
        }
        
        uint64_t bef_writ = stream_out().bytes_written();
        proceed = true;
        _reassembler.push_substring(static_cast<std::string>(data.str().substr(lskip,data.size()-rskip)),max(unwrap(head.seqno,_isn,nextSeqno),nextSeqno)-raw,false);
        rec = 0;
        uint64_t aft_writ = stream_out().bytes_written();
        nextSeqno = nextSeqno + aft_writ - bef_writ;

        if (closeInput == true) {
            stream_out().end_input();
            haveNext = false;
            nextSeqno++;
        }
        return true;

    } else {
        return false;
    }

// }

    // --- Hint ------
        // convert the seqno into absolute seqno
    // uint64_t checkpoint = _reassembler.ack_index();
    // uint64_t abs_seqno = unwrap(head.seqno, _isn, checkpoint);
    // uint64_t stream_idx = abs_seqno - _synReceived;
    // --- Hint ------  

    // ... 
}

optional<WrappingInt32> TCPReceiver::ackno() const {
    if (_synReceived == true) {
        return wrap(nextSeqno,_isn);
    } else {
        return optional<WrappingInt32>{};
    }
}

size_t TCPReceiver::window_size() const { return stream_out().remaining_capacity(); }

