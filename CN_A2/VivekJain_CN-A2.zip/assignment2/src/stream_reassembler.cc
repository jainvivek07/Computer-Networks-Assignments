#include "stream_reassembler.hh"

// You will need to add private members to the class declaration in `stream_reassembler.hh`

template <typename... Targs>
void DUMMY_CODE(Targs &&... /* unused */) {}

using namespace std;

StreamReassembler::StreamReassembler(const size_t capacity)
    :_output(capacity), capp(capacity),arriving(0),correctdone(0),leftbyte(0),prevSeg(),mpp()
{}


//! \details This function accepts a substring (aka a segment) of bytes,
//! possibly out-of-order, from the logical stream, and assembles any newly
//! contiguous substrings and writes them into the output stream in order.
void StreamReassembler::push_substring(const string &data, const size_t index, const bool eof) {

    size_t a = data.size();
    size_t b = stream_out().remaining_capacity();
    size_t minSize = min(a,b);

    // overlapping and coming bytes include new bytes
    //1 2 3 4 : now 5 is needed but we received 3 4 5 6
    if (index<arriving && index+data.size()>arriving) {
        size_t start = arriving-index-1;
            for (size_t i = start; i<data.size(); i++) {
                if (i!=data.size()-1 && (stream_out().remaining_capacity()!=0 || mpp.count(index+i)==0)) {
                    mpp[index+i] = pair<std::string,bool>(data.substr(i,1),false);
                    leftbyte++;
                } else if(i==data.size()-1 && (stream_out().remaining_capacity()!=0 || mpp.count(index+i)==0)) {
                    mpp[index+i] = pair<std::string,bool>(data.substr(i,1),eof);
                    leftbyte++;
                }
            }

    } else if(index<arriving && index+data.size()<=arriving) return; // overlapping and coming bytes don't include new bytes
                                                                    //1 2 3 4 : now 5 is needed but we received 3 4

    //no overlapping and coming bytes are the bytes that might be needed in future, if so, we store them in buffer
    //1 2 3 4 : now 5 is needed but we received 7 8 9
    if (index > arriving) {
        for (size_t i=0;i<minSize;i++) {
            size_t z = index+i;
            if (i!=minSize-1 && mpp.count(z)==0) {
                mpp[z] = std::make_pair(data.substr(i,1),false);
                leftbyte++;
            } else if (i==minSize-1 && mpp.count(z)==0){
                mpp[z] = pair<std::string,bool>(data.substr(i,1),eof);
                leftbyte++;
            }
        }
        return;
    }

    // bytes that come are exactly the bytes that are needed. 1 2 3 4 : now 5 is needed and we received 5
    if (index == arriving) {
        prevSeg=data;

        for (size_t i=1;i<=minSize;i++) {
            _output.write(data.substr(i-1,1));
            arriving++;

            if (mpp.count(index+i-1)!=0) {
                mpp.erase(index+i-1);
                leftbyte--;
            }
        }

        if (eof == true) {
            _output.end_input();
        }
    }
 
    while (mpp.count(arriving) != 0 && _output.remaining_capacity() != 0) {
        std::string w = mpp[arriving].first;
        bool bo = mpp[arriving].second;
        mpp.erase(arriving);
        leftbyte--;
        _output.write(w);
        if (bo) {
            _output.end_input();
        }
        arriving++;
    }

}

size_t StreamReassembler::unassembled_bytes() const { return leftbyte; }

bool StreamReassembler::empty() const { return stream_out().buffer_empty(); }

size_t StreamReassembler::ack_index() const { return arriving; }
