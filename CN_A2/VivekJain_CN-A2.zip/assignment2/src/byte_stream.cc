#include "byte_stream.hh"

#include <algorithm>
#include <bits/stdc++.h>
// You will need to add private members to the class declaration in `byte_stream.hh`

/* Replace all the dummy definitions inside the methods in this file. */


using namespace std;

ByteStream::ByteStream(const size_t capa)
    : capacity_(capa), input_ended_(false), error_(false), total_bytes_read_(0), total_bytes_written_(0) {

}


size_t ByteStream::write(const string &data) {

    if (input_ended_ || error_) {
        return 0; // Stream has ended or encountered an error
    }

    // Calculate the number of bytes that can be written without exceeding capacity
    size_t bytes_to_write = min(data.length(), capacity_ - buffer_.size());

    // Copy the data into the stream
    buffer_.insert(buffer_.end(), data.begin(), data.begin() + bytes_to_write);

    total_bytes_written_ += bytes_to_write;

    return bytes_to_write;

}

//! \param[in] len bytes will be copied from the output side of the buffer
string ByteStream::peek_output(const size_t len) const {

    // Ensure that len does not exceed the buffer size
    size_t bytes_to_peek = min(len, buffer_.size());

    // Create a string from the data without removing it from the buffer
    string peeked_output(buffer_.begin(), buffer_.begin() + bytes_to_peek);

    return peeked_output;

}


//! \param[in] len bytes will be removed from the output side of the buffer
void ByteStream::pop_output(const size_t len) {
    // Check if len is greater than the buffer size
    if (len > buffer_.size()) {
        error_ = true;  //error flag
        return;
    }

    // Ensure that len does not exceed the buffer size
    size_t bytes_to_pop = min(len, buffer_.size());

    // Remove bytes from the buffer
    buffer_.erase(buffer_.begin(), buffer_.begin() + bytes_to_pop);

    // Update total_bytes_read_
    total_bytes_read_ += bytes_to_pop;

}

//! Read (i.e., copy and then pop) the next "len" bytes of the stream
//! \param[in] len bytes will be popped and returned
//! \returns a string
string ByteStream::read(const size_t len) {
    // Check if len is greater than the buffer size
    if (len > buffer_.size()) {
        error_ = true;
        return "";
    }

    // Ensure that len does not exceed the buffer size
    size_t bytes_to_read = min(len, buffer_.size());

    // Create a string from the data and remove it from the buffer
    string read_data(buffer_.begin(), buffer_.begin() + bytes_to_read);

    buffer_.erase(buffer_.begin(), buffer_.begin() + bytes_to_read);

    total_bytes_read_ += bytes_to_read;

    return read_data;
}


void ByteStream::end_input() {
    input_ended_ = true;
}


bool ByteStream::input_ended() const {
    return input_ended_;
}


size_t ByteStream::buffer_size() const {
    return buffer_.size();
}


bool ByteStream::buffer_empty() const {
    return buffer_.empty();
}


bool ByteStream::eof() const {
    return input_ended_ && buffer_.empty();
}


size_t ByteStream::bytes_written() const {
    return total_bytes_written_;
}


size_t ByteStream::bytes_read() const {
    return total_bytes_read_;
}


size_t ByteStream::remaining_capacity() const {
    return capacity_ - buffer_.size();
}


