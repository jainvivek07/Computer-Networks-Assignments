#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>

#define MAX_CLIENTS 4050

uint64_t fact(uint64_t n) {
    uint64_t result = 1;
    if (n > 20) n = 20;
    for (uint64_t i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int listen_sd, new_sd;
    int client_sockets[MAX_CLIENTS];
    struct pollfd ufds[MAX_CLIENTS];
    char buffer[1024];

    for (int i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = -1;
        ufds[i].fd = -1;
    }

    if ((listen_sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket() failed");
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(listen_sd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    listen(listen_sd, MAX_CLIENTS);

    ufds[0].fd = listen_sd;
    ufds[0].events = POLLIN;

    while (1) {
        int num_ready = poll(ufds, MAX_CLIENTS, -1);
        if (num_ready == -1) {
            perror("poll failed");
            break;
        }

        if (ufds[0].revents & POLLIN) {
            if ((new_sd = accept(listen_sd, NULL, NULL)) == -1) {
                perror("accept failed");
            } else {
                int i;
                for (i = 1; i < MAX_CLIENTS; i++) {
                    if (client_sockets[i] == -1) {
                        client_sockets[i] = new_sd;
                        ufds[i].fd = new_sd;
                        ufds[i].events = POLLIN;
                        break;
                    }
                }
            }
        }

        for (int i = 1; i < MAX_CLIENTS; i++) {
            if (client_sockets[i] != -1 && ufds[i].revents & POLLIN) {
                int n = recv(client_sockets[i], buffer, sizeof(buffer), 0);
                if (n <= 0) {
                    close(client_sockets[i]);
                    ufds[i].fd = -1;
                    client_sockets[i] = -1;
                } else {
                    buffer[n] = '\0';
                    uint64_t number;
                    if (sscanf(buffer, "%" PRIu64, &number) == 1) {
                        uint64_t result = fact(number);
                        snprintf(buffer, sizeof(buffer), "%" PRIu64, result);
                        send(client_sockets[i], buffer, strlen(buffer), 0);
                    }
                }
            }
        }
    }

    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (client_sockets[i] != -1) {
            close(client_sockets[i]);
        }
    }
    close(listen_sd);

    return 0;
}

