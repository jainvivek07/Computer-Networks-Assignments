#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>


unsigned long long factorial(uint64_t n) {
    if (n > 20) n = 20;
    uint64_t fact = 1;
    for(uint64_t i = 2; i <= n; i++)
        fact *= i;
    return fact;
}

void *handle_client(void *client_sock) {
    int sock = *(int*)client_sock;
    char buffer[1024];
    unsigned long long fact;
    int str_len;

    while ((str_len = read(sock, buffer, 1024)) != 0) {
        unsigned long long n = *(unsigned long long*)buffer;
        if (n > 20)
            n = 20;
        unsigned long long result = factorial(n);
        write(sock, &result, sizeof(result));
    }

    close(sock);
    free(client_sock);
    return NULL;
}

int main() {
    int server_sock, *client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(struct sockaddr_in);

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_sock, 4010);

    while(1) {
        client_sock = malloc(sizeof(int));
        *client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &addr_len);

        pthread_t thread_id;
        pthread_create(&thread_id, NULL, handle_client, (void*)client_sock);
    }

    close(server_sock);
    return 0;
}

