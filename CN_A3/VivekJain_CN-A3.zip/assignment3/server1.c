#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

unsigned long long fact(unsigned long long n) {
    if (n == 0)
        return 1;
    else
        return n * fact(n - 1);
}

int main() {
    int serv_sock, clnt_sock;
    struct sockaddr_in serv_adr, clnt_adr;
    socklen_t adr_sz;
    pid_t pid;
    char buf[1024];
    int str_len, i;

    serv_sock = socket(PF_INET, SOCK_STREAM, 0);
    memset(&serv_adr, 0, sizeof(serv_adr));
    serv_adr.sin_family = AF_INET;
    serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_adr.sin_port = htons(12345);

    if (bind(serv_sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1)
        perror("bind error");
        
    
    if (listen(serv_sock, 5) == -1)
        perror("listen error");

    while (1) {
        adr_sz = sizeof(clnt_adr);
        clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
        if (clnt_sock == -1)
            continue;

        pid = fork();
        if (pid == -1) {
            close(clnt_sock);
            continue;
        }
        if (pid == 0) {
            close(serv_sock);

            while ((str_len = read(clnt_sock, buf, 1024)) != 0) {
                unsigned long long n = *(unsigned long long*)buf;
                if (n > 20)
                    n = 20;
                unsigned long long result = fact(n);
                write(clnt_sock, &result, sizeof(result));
            }

            close(clnt_sock);
            //puts("client disconnected");
            return 0;
        } else
            close(clnt_sock);
    }
    
    close(serv_sock);
    return 0;
}

