#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>

#define MAX_CLIENTS 4050

uint64_t fact(uint64_t n) {
    uint64_t result = 1;
    if (n > 20) n = 20;
    for (uint64_t i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int listen_sd, max_sd, new_sd;
    int client_sockets[MAX_CLIENTS];
    fd_set master_set, working_set;

    for (int i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = -1;
    }
    FD_ZERO(&master_set);

    if ((listen_sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket failed");
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(listen_sd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind failed");
    }

    if (listen(listen_sd, MAX_CLIENTS) == -1) {
        perror("listen failed");
    }

    FD_SET(listen_sd, &master_set);
    max_sd = listen_sd;

    while (1) {
        working_set = master_set;
        if (select(max_sd + 1, &working_set, NULL, NULL, NULL) == -1) {
            perror("select failed");
            break;
        }

        if (FD_ISSET(listen_sd, &working_set)) {
            if ((new_sd = accept(listen_sd, NULL, NULL)) == -1) {
                perror("accept failed");
            } else {
                int i;
                for (i = 0; i < MAX_CLIENTS; i++) {
                    if (client_sockets[i] == -1) {
                        client_sockets[i] = new_sd;
                        FD_SET(new_sd, &master_set);
                        if (new_sd > max_sd) {
                            max_sd = new_sd;
                        }
                        break;
                    }
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (client_sockets[i] != -1 && FD_ISSET(client_sockets[i], &working_set)) {
                char buffer[1024];
                int n = recv(client_sockets[i], buffer, sizeof(buffer), 0);
                if (n <= 0) {
                    close(client_sockets[i]);
                    FD_CLR(client_sockets[i], &master_set);
                    client_sockets[i] = -1;
                } else {
                    buffer[n] = '\0';
                    uint64_t number;
                    if (sscanf(buffer, "%" PRIu64, &number) == 1) {
                        uint64_t result = fact(number);
                        snprintf(buffer, sizeof(buffer), "%" PRIu64, result);
                        send(client_sockets[i], buffer, strlen(buffer), 0);
                    }
                }
            }
        }
    }
	
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (client_sockets[i] != -1) {
            close(client_sockets[i]);
        }
    }
    close(listen_sd);

    return 0;
}

