#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>

#define MAX_CLIENTS 4050

uint64_t fact(uint64_t n) {
    uint64_t result = 1;
    if (n > 20) n = 20;
    for (uint64_t i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int listen_sd, new_sd;
    int client_sockets[MAX_CLIENTS];
    int epoll_fd;
    struct epoll_event event, events[MAX_CLIENTS];
    char buffer[1024];

    for (int i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = -1;
    }

    if ((listen_sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket() failed");
        exit(-1);
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(listen_sd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    listen(listen_sd, MAX_CLIENTS);
    
    epoll_fd = epoll_create1(0);
    if (epoll_fd == -1) {
        perror("epoll_create failed");
    }

    event.events = EPOLLIN;
    event.data.fd = listen_sd;
    
    epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_sd, &event);
    
    while (1) {
        int num_ready = epoll_wait(epoll_fd, events, MAX_CLIENTS, -1);
        if (num_ready == -1) {
            perror("epoll_wait failed");
            break;
        }

        for (int i = 0; i < num_ready; i++) {
            if (events[i].data.fd == listen_sd) {
                if ((new_sd = accept(listen_sd, NULL, NULL)) == -1) {
                    perror("accept failed");
                } else {
                    int j;
                    for (j = 0; j < MAX_CLIENTS; j++) {
                        if (client_sockets[j] == -1) {
                            client_sockets[j] = new_sd;
                            event.events = EPOLLIN;
                            event.data.fd = new_sd;
                            if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, new_sd, &event) == -1) {
                                //perror("epoll_ctl failed");
                            }
                            break;
                        }
                    }
                    
                }
            } else {
                int fd = events[i].data.fd;
                int n = recv(fd, buffer, sizeof(buffer), 0);
                if (n <= 0) {
                    close(fd);
                    client_sockets[i] = -1;
                    if (epoll_ctl(epoll_fd, EPOLL_CTL_DEL, fd, NULL) == -1) {
                        //perror("epoll_ctl failed");
                    }
                } else {
                    buffer[n] = '\0';
                    uint64_t number;
                    if (sscanf(buffer, "%" PRIu64, &number) == 1) {
                        uint64_t result = fact(number);
                        snprintf(buffer, sizeof(buffer), "%" PRIu64, result);
                        send(fd, buffer, strlen(buffer), 0);
                    }
                }
            }
        }
    }

    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (client_sockets[i] != -1) {
            close(client_sockets[i]);
        }
    }
    close(listen_sd);
    close(epoll_fd);

    return 0;
}

