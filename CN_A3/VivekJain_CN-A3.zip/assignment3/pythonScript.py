from scapy.all import *
import matplotlib.pyplot as plt

#pcap_file = ["selectCap.pcap", "pthreadCap.pcap", "selectCap.pcap", "pollCap.pcap", "epollCap.pcap"]
"""#couldn't do this and plot all of these together as it took a lot of time and all the plots came, too much memory and cpu was consumed and system was hanged and need to be closed. so i had to plot for each one by one."""

pcap_file = "epollCap.pcap"
throughput_values, latency_values = [], []

flows = {}
packets = rdpcap(pcap_file)

for packet in packets:
    if TCP in packet:
        flow_key = (packet[IP].src, packet[TCP].sport, packet[IP].dst, packet[TCP].dport)
        
        if flow_key not in flows:
            flows[flow_key] = {'packets': 0, 'bytes': 0, 'start_time': packet.time}

        flows[flow_key]['packets'] += 1
        flows[flow_key]['bytes'] += len(packet)

for flow_key, flow_data in flows.items():
    end_time = packets[-1].time
    duration = end_time - flow_data['start_time']
    throughput = (flow_data['bytes'] * 8) / duration
    latency = (duration / flow_data['packets']) * 1000 
    throughput_values.append(throughput)
    latency_values.append(latency)

plt.figure(1)
plt.plot(throughput_values, label="Throughput (bps)")
plt.xlabel("Flow")
plt.ylabel("Throughput (bps)")
plt.title("Throughput")
plt.legend()
plt.grid(True)

plt.figure(2)
plt.plot(latency_values, label="Latency (ms)")
plt.xlabel("Flow")
plt.ylabel("Latency (ms)")
plt.title("Latency")
plt.legend()
plt.grid(True)

plt.show()

